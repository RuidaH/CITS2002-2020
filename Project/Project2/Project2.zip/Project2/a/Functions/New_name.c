#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
//

void New_path( char *oldpath, char *newpath ) {
    
    char split[] = "
    
}

 
int main(int argc, char *argv[]) {
   
    New_path(argv[1], argv[2]);
    
    return 0;
}

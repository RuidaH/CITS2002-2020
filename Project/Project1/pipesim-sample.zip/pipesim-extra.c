//  FUNCTIONS TO SUPPORT WEB-BASED SAMPLE SOLUTION - NO NEED TO UNDERSTAND THIS

//  THIS FILE REQUIRES THESE VARIABLES AND FUNCTIONS FROM pipesim.c
extern  int     timetaken;
extern	int     READY_queue[];
extern	int     nready;
extern  void    LOG_pipes(char indent[]);

#include <stdarg.h>

void PANIC(char *fmt, ...)
{
    va_list	ap;

    va_start(ap, fmt);
    vfprintf(stdout, fmt, ap);
    va_end(ap);
    exit(EXIT_FAILURE);
}

void LOG_READY_queue(void)
{
    if(nready > 0) {
        char str[256], *s = str;

        for(int r=0 ; r<nready ; ++r) {
            sprintf(s, "%i%s", READY_queue[r], (r < (nready-1)) ? "<-" : "");
            while(*s)
                ++s;
        }
        printf("RQ: %s", str);
    }
}

char    logbuf[256]     = { '\0' };
char    *lp             = logbuf;
int	loglines        = 0;
int	logusecs        = 0;

#define	MAX_LOGLINES	1000
void FLUSH_LOG(void)
{
    if(logbuf[0]) {
        printf("@%06i   %-72s", logusecs, logbuf);
        LOG_READY_queue();
        printf("\n");
        LOG_pipes("          ");
	if(++loglines >= MAX_LOGLINES) {
	    PANIC("hmmm, too much output - giving up!\n");
	}
    }
    logbuf[0]   = '\0';
    lp          = logbuf;
    logusecs    = timetaken;
}
#undef	MAX_LOGLINES

void LOG(char *fmt, ...)
{
    va_list	ap;

    if(*fmt == '\0') {
        logbuf[0]   = '\0';
        lp          = logbuf;
        logusecs    = timetaken;
        return;
    }
    if(logbuf[0]) {
        *lp++   = ',';
        *lp++   = ' ';
    }
    va_start(ap, fmt);
    vsprintf(lp, fmt, ap);
    va_end(ap);

    while(*lp) {
        ++lp;
    }
    if(*(lp-1) == '\n') {
        *(lp-1) = '\0';
        FLUSH_LOG();
    }
}


#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

//  FUNCTIONS TO SUPPORT WEB-BASED SAMPLE SOLUTION - NO NEED TO UNDERSTAND
#include "pipesim-extra.c"


/*  CITS2002 Project 1 2020
    Name:                student-name
    Student number(s):   student-number
 */

//  MAXIMUM NUMBER OF PROCESSES OUR SYSTEM SUPPORTS (PID=1..20)
#define MAX_PROCESSES                       20

//  MAXIMUM NUMBER OF SYSTEM-CALLS EVER MADE BY ANY PROCESS
#define MAX_SYSCALLS_PER_PROCESS            50

//  MAXIMUM NUMBER OF PIPES THAT ANY SINGLE PROCESS CAN HAVE OPEN (0..9)
#define MAX_PIPE_DESCRIPTORS_PER_PROCESS    10

//  TIME TAKEN TO SWITCH ANY PROCESS FROM ONE STATE TO ANOTHER
#define USECS_TO_CHANGE_PROCESS_STATE       5

//  TIME TAKEN TO TRANSFER ONE BYTE TO/FROM A PIPE
#define USECS_PER_BYTE_TRANSFERED           1


//  ---------------------------------------------------------------------
//  YOUR DATA STRUCTURES, VARIABLES, AND FUNCTIONS SHOULD BE ADDED HERE:

int timetaken           = 0;        // will accumulate our final result

#define UNKNOWN         (-1)
#define INIT_PROCESS    1

//  POSSIBLE PROCESS STATES  (COULD BE AN enum INSTEAD):
#define NEW             0
#define RUNNING         1
#define READY           2
#define SLEEPING        3
#define WAITING         4
#define WRITEBLOCKED    5
#define READBLOCKED     6
#define EXITED          7

char *state_names[] = {
        "NEW", "RUNNING", "READY",
        "SLEEPING", "WAITING", "WRITEBLOCKED", "READBLOCKED", "EXITED"
};

//  SUPPORTED SYSTEM-CALLS  (COULD BE AN enum INSTEAD):
#define SYS_COMPUTE     0
#define SYS_SLEEP       1
#define SYS_EXIT        2
#define SYS_FORK        3
#define SYS_WAIT        4
#define SYS_PIPE        5
#define SYS_WRITEPIPE   6
#define SYS_READPIPE    7

char *syscall_names[] = {
        "compute", "sleep", "exit",
        "fork", "wait", "pipe", "writepipe", "readpipe"
};

//  ----------------------------------------------------------------------
//  VARIABLES AND FUNCTIONS TO MANAGE THE PROCESSES

struct {
    int         state;                  // one of NEW, RUNNING, READY ...
    int         nextsyscall;            // which syscalls[] is executing

    struct {
        int     type;
        int     usecs;
        int     otherPID;
        int     pipedesc;
        int     nbytes;
    } syscalls[MAX_SYSCALLS_PER_PROCESS];

    int         nsyscalls;              // number of syscalls[] recorded
    int         sleep_until;
    int         waiting_for_me;         // process waiting for me (parent)

    int         mypipes[MAX_PIPE_DESCRIPTORS_PER_PROCESS];

} process[MAX_PROCESSES+1];		// indexed by PID -> 1..MAX_PROCESSES

void init_processes(void)
{
    for(int p=1 ; p<=MAX_PROCESSES ; ++p) {
        process[p].state            = NEW;
        process[p].nsyscalls        = 0;
        process[p].nextsyscall      = 0;
        process[p].waiting_for_me   = UNKNOWN;

        for(int d=0 ; d<MAX_PIPE_DESCRIPTORS_PER_PROCESS ; ++d) {
            process[p].mypipes[d]   = UNKNOWN;
        }
    }
    process[INIT_PROCESS].state   = RUNNING;
}

//  ----------------------------------------------------------------------
//  VARIABLES AND FUNCTIONS TO MANAGE THE READY-QUEUE

int  READY_queue[MAX_PROCESSES];
int  nready  = 0;

void init_READY_queue(void) { nready  = 0; }
int  len_READY_queue(void)  { return nready; }

void append_to_READY_queue(int PID)
{
    READY_queue[nready++] = PID;
}

int remove_head_of_READY_queue(void)
{
    if(nready <= 0) {
        PANIC("Attempt to remove from an empty Ready queue. Please report this on help2002.\n");
    }

    int PID   = READY_queue[0];

    for(int r=0 ; r<nready ; ++r) {
        READY_queue[r]  = READY_queue[r+1];
    }
    --nready;
    return PID;
}

//  ---------------------------------------------------------------------
//  VARIABLES AND FUNCTIONS TO MANAGE THE PIPES

#define MAX_PIPES       (MAX_PROCESSES * MAX_PIPE_DESCRIPTORS_PER_PROCESS / 2)

struct {
    int         writingPID, writingPD;
    int         readingPID, readingPD;
    int         nbytes;
    bool        changed;
} pipes[MAX_PIPES];

void init_pipes(void)
{
    for(int p=0 ; p<MAX_PIPES ; ++p) {
        pipes[p].writingPID = UNKNOWN;
        pipes[p].writingPD  = UNKNOWN;

        pipes[p].readingPID = UNKNOWN;
        pipes[p].readingPD  = UNKNOWN;

        pipes[p].nbytes     = 0;
        pipes[p].changed    = false;
    }
}

void LOG_pipes(char indent[])
{
    for(int p=0 ; p<MAX_PIPES ; ++p) {
        if(pipes[p].changed) {
            fputs(indent, stdout);
            if(pipes[p].writingPID == UNKNOWN) {
                printf("none");
            }
            else {
                printf("p%i/%i", pipes[p].writingPID, pipes[p].writingPD);
            }
            if(pipes[p].nbytes == 0) {
                printf(" => [..empty..] => ");
            }
            else {
                printf(" => [..%i bytes..] => ", pipes[p].nbytes);
            }
            if(pipes[p].readingPID == UNKNOWN) {
                printf("none\n");
            }
            else {
                printf("p%i/%i\n", pipes[p].readingPID, pipes[p].readingPD);
            }
            pipes[p].changed    = false;
        }
    }
}

//  CONNECT PIPE'S WRITING-END IN PARENT PROCESS TO READING-END IN CHILD PROCESS
void connect_pipes(int onCPU, int childPID)
{
    for(int d=0 ; d<MAX_PIPE_DESCRIPTORS_PER_PROCESS ; ++d) {
        int p   = process[onCPU].mypipes[d];

        if(p != UNKNOWN) {
            if(pipes[p].writingPID == onCPU && pipes[p].readingPID == UNKNOWN) {
                process[childPID].mypipes[d]    = p;
                pipes[p].readingPID             = childPID;
                pipes[p].readingPD            = pipes[p].writingPD;
                pipes[p].changed                = true;
            }
        }
    }
}

int find_unused_pipe(int writingPID, int writingPD)
{
    for(int p=0 ; p<MAX_PIPES ; ++p) {
        if(pipes[p].writingPID == UNKNOWN && pipes[p].readingPID == UNKNOWN) {
            pipes[p].writingPID = writingPID;
            pipes[p].writingPD  = writingPD;

            pipes[p].readingPID = UNKNOWN;
            pipes[p].readingPD  = UNKNOWN;

            pipes[p].changed    = true;
            return p;
        }
    }
    PANIC("no unused pipes\n");
    return 0;
}

//  ----------------------------------------------------------------------
//  SUPPORTING FUNCTIONS TO MAKE run_simulation() EASIER TO READ

void next_syscall(int PID)
{
    ++process[PID].nextsyscall;
}

void inc_timetaken(int inc)
{
    timetaken   += inc;
    LOG("");
}

void change_state(int PID, int newstate)
{
    int oldstate    = process[PID].state;

    LOG("p%i.%s->%s\n", PID, state_names[oldstate], state_names[newstate]);

    if(newstate == READY) {
        append_to_READY_queue(PID);
    }
    process[PID].state    = newstate;
    inc_timetaken(USECS_TO_CHANGE_PROCESS_STATE);
}

//  ---------------------------------------------------------------------

void run_simulation(int timequantum, int pipesize)
{
    int     nprocs_alive    = 1;
    int     nprocs_sleeping = 0;
    int     onCPU           = INIT_PROCESS;         // PID that is on CPU

    init_READY_queue();
    init_pipes();

    timetaken               = 0;
    LOG("");
    LOG("BOOT, p%i.RUNNING\n", INIT_PROCESS);

//  CONTINUE UNTIL THE SYSTEM HALTS
    while(nprocs_alive > 0) {
        LOG("");

        if(onCPU == UNKNOWN) {
            onCPU   = remove_head_of_READY_queue();
            change_state(onCPU, RUNNING);
        }

        int next    = process[onCPU].nextsyscall;
        int syscall = process[onCPU].syscalls[next].type;

        switch (syscall) {
        case SYS_COMPUTE: {
            int usecs   = process[onCPU].syscalls[next].usecs;

            LOG("p%i:%s()", onCPU, syscall_names[syscall]);
            if(usecs <=timequantum) {               // finished computing
                LOG("for %iusec (now completed)\n", usecs);
                process[onCPU].syscalls[next].usecs   = 0;
                next_syscall(onCPU);
                inc_timetaken(usecs);
            }
            else {                                  // more computing
                process[onCPU].syscalls[next].usecs   -= timequantum;
                LOG("for %iusec (%i usecs remaining)\n",
                        timequantum, process[onCPU].syscalls[next].usecs);
                inc_timetaken(timequantum);
            }
            change_state(onCPU, READY);
            break;
        }

        case SYS_SLEEP: {
            int usecs   = process[onCPU].syscalls[next].usecs;

            LOG("p%i:%s() for %iusecs", onCPU, syscall_names[syscall], usecs);
            ++nprocs_sleeping;
            process[onCPU].sleep_until = timetaken+usecs+USECS_TO_CHANGE_PROCESS_STATE;
            change_state(onCPU, SLEEPING);
            break;
        }

        case SYS_EXIT: {
            LOG("p%i:%s()", onCPU, syscall_names[syscall]);

//  CLEANUP UP ANY PIPES CONNECTED TO THIS PROCESS
	    for(int d=0 ; d<MAX_PIPE_DESCRIPTORS_PER_PROCESS ; ++d) {
		int index   = process[onCPU].mypipes[d];

		if(index != UNKNOWN) {
		    if(pipes[index].writingPID == onCPU) {
			pipes[index].writingPID = UNKNOWN;
                        pipes[index].changed    = true;
		    }
		    else if(pipes[index].readingPID == onCPU) {
			pipes[index].readingPID = UNKNOWN;
                        pipes[index].changed    = true;
		    }
		}
	    }

//  IS ANOTHER OTHER PROCESS (THE PARENT) WAITING ON THIS TERMINATING PROCESS?
            int p = process[onCPU].waiting_for_me;

            if(p != UNKNOWN) {
                LOG("p%i has been waiting for p%i", p, onCPU);
                next_syscall(p);
                change_state(p, READY);
            }

            --nprocs_alive;
            change_state(onCPU, EXITED);
            break;
        }

        case SYS_FORK: {
            int childPID = process[onCPU].syscalls[next].otherPID;

            LOG("p%i:%s(),  new childPID=%i", onCPU, syscall_names[syscall], childPID);
            ++nprocs_alive;

            connect_pipes(onCPU, childPID);
            change_state(childPID, READY);      // child runs before parent

            next_syscall(onCPU);
            change_state(onCPU, READY);
            break;
	}

        case SYS_WAIT: {
            int otherPID = process[onCPU].syscalls[next].otherPID;

            LOG("p%i:%s(), for childPID=%i", onCPU, syscall_names[syscall], otherPID);
            process[otherPID].waiting_for_me = onCPU;
            change_state(onCPU, WAITING);
            break;
	}

        case SYS_PIPE: {
            int pipedesc   = process[onCPU].syscalls[next].pipedesc;

//  PROCESS CREATING NEW PIPE BECOMES THE WRITING END (NO INITIAL READER)
            LOG("p%i:%s() pipedesc=%i", onCPU, syscall_names[syscall], pipedesc);

            process[onCPU].mypipes[pipedesc]    = find_unused_pipe(onCPU, pipedesc);
            next_syscall(onCPU);
            change_state(onCPU, READY);
            break;
        }

        case SYS_WRITEPIPE: {
            int pipedesc    = process[onCPU].syscalls[next].pipedesc;
            int whichpipe   = process[onCPU].mypipes[pipedesc];

            int nbytes      = process[onCPU].syscalls[next].nbytes;
            int space_available = (pipesize - pipes[whichpipe].nbytes);

//  IS THERE SUFFICIENT SPACE IN THE PIPE TO COMPLETE THIS WRITE?
            if(nbytes <= space_available) {		// yes
                pipes[whichpipe].nbytes                 += nbytes;  // add to pipe
                pipes[whichpipe].changed                 = true;
                process[onCPU].syscalls[next].nbytes     = 0;       // completed

                LOG("p%i:%s() %i bytes to pipedesc=%i (completed)",
                                onCPU, syscall_names[syscall], nbytes, pipedesc);
                next_syscall(onCPU);
                change_state(onCPU, READY);
                inc_timetaken(nbytes * USECS_PER_BYTE_TRANSFERED);
            }
//  INSUFFICIENT SPACE => PERFORM PARTIAL WRITE, THEN BLOCK UNTIL SPACE AVAILABLE
            else {					// no
                nbytes                                   = space_available;
                pipes[whichpipe].nbytes                  = pipesize; // now full
                pipes[whichpipe].changed                 = true;
                process[onCPU].syscalls[next].nbytes    -= nbytes;  // partial write

                LOG("p%i:%s() %i bytes to pipedesc=%i\n",
                                onCPU, syscall_names[syscall], nbytes, pipedesc);
                change_state(onCPU, WRITEBLOCKED);
                inc_timetaken(nbytes * USECS_PER_BYTE_TRANSFERED);
            }
            break;
        }

        case SYS_READPIPE: {
            int pipedesc        = process[onCPU].syscalls[next].pipedesc;
            int whichpipe       = process[onCPU].mypipes[pipedesc];

            int nbytes          = process[onCPU].syscalls[next].nbytes;
            int bytes_available = pipes[whichpipe].nbytes;

//  PIPE IS EMPTY => MUST BLOCK UNTIL SOME DATA IS WRITTEN TO PIPE
            if(bytes_available == 0) {
                LOG("p%i:%s() from empty pipedesc=%i",
                                onCPU, syscall_names[syscall], pipedesc);
                if(pipes[whichpipe].writingPID == UNKNOWN) {
                    PANIC("the process writing to this pipe has terminated\n");
                }
                change_state(onCPU, READBLOCKED);
            }
//  ARE THERE SUFFICIENT BYTES IN THE PIPE TO SATIFY OUR FULL READ REQUEST?
            else if(nbytes <= bytes_available) {	// yes
                pipes[whichpipe].nbytes                 -= nbytes;  // remove from pipe
                pipes[whichpipe].changed                 = true;
                process[onCPU].syscalls[next].nbytes     = 0;       // completed

                LOG("p%i:%s() %i bytes from pipedesc=%i (completed)",
                                onCPU, syscall_names[syscall], nbytes, pipedesc);
                next_syscall(onCPU);
                change_state(onCPU, READY);
                inc_timetaken(nbytes * USECS_PER_BYTE_TRANSFERED);
            }
//  INSUFFICIENT BYTES IN PIPE => PERFORM PARTIAL READ, BLOCK UNTIL MORE DATA
            else {          // want nbytes > bytes_available
                nbytes                                   = bytes_available;

                pipes[whichpipe].nbytes                 = 0;        // now empty
                pipes[whichpipe].changed                 = true;
                process[onCPU].syscalls[next].nbytes    -= nbytes;  // partial ready

                LOG("p%i:%s() %i bytes from pipedesc=%i",
                                onCPU, syscall_names[syscall], nbytes, pipedesc);
                change_state(onCPU, READBLOCKED);
                inc_timetaken(nbytes * USECS_PER_BYTE_TRANSFERED);
            }
            break;
          }

        default:
            PANIC("p%i: unknown syscall=%i()\n", onCPU, syscall);

        }                           // END OF   switch (syscall)
        FLUSH_LOG();
        onCPU       = UNKNOWN;

//  DETERMINE IF ANY PROCESSES BLOCKED ON PIPES CAN BECOME READY
        for(int p=1 ; p<=MAX_PROCESSES ; ++p) {

            if(process[p].state == WRITEBLOCKED) {
                int next        = process[p].nextsyscall;
                int pipedesc    = process[p].syscalls[next].pipedesc;
                int whichpipe   = process[p].mypipes[pipedesc];

                if(pipes[whichpipe].nbytes < pipesize) {    // pipe has space
                    LOG("p%i can write its pipedesc=%i\n", p, pipedesc);
                    change_state(p, READY);
                }
            }
            else if(process[p].state == READBLOCKED) {
                int next        = process[p].nextsyscall;
                int pipedesc    = process[p].syscalls[next].pipedesc;
                int whichpipe   = process[p].mypipes[pipedesc];

                if(pipes[whichpipe].nbytes > 0) {           // pipe has data
                    LOG("p%i can read its pipedesc=%i\n", p, pipedesc);
                    change_state(p, READY);
                }
            }
        }

//  FIND THE EARLIEST TIME THAT ANY SLEEPING PROCESS CAN AWAKEN
        if(nprocs_sleeping > 0) {
            int earliest    = 1000000000;                   // any huge number

            for(int p=1 ; p<=MAX_PROCESSES ; ++p) {
                if(process[p].state == SLEEPING && process[p].sleep_until <= earliest) {
                    earliest    = process[p].sleep_until;
                }
            }
            if(len_READY_queue() == 0 && earliest > timetaken) {
                timetaken   = earliest;
                LOG("");
                LOG("CPU is idle, time has advanced\n");
            }

//  MOVE ALL WAKING PROCESSES TO THE READY QUEUE
            for(int p=1 ; p<=MAX_PROCESSES ; ++p) {
                if(process[p].state == SLEEPING && process[p].sleep_until <= timetaken) {
                    LOG("p%i finishes sleeping", p);
                    --nprocs_sleeping;
                    next_syscall(p);
                    change_state(p, READY);
                }
            }
        }
        FLUSH_LOG();
    }
    LOG("HALT (no processes alive)\n");
}

//  ---------------------------------------------------------------------
//  FUNCTIONS TO VALIDATE FIELDS IN EACH eventfile - NO NEED TO MODIFY

int check_PID(char word[], int lc)
{
    int PID = atoi(word);

    if(PID <= 0 || PID > MAX_PROCESSES) {
        printf("invalid PID '%s', line %i\n", word, lc);
        exit(EXIT_FAILURE);
    }
    return PID;
}

int check_microseconds(char word[], int lc)
{
    int usecs = atoi(word);

    if(usecs <= 0) {
        printf("invalid usecs '%s', line %i\n", word, lc);
        exit(EXIT_FAILURE);
    }
    return usecs;
}

int check_descriptor(char word[], int lc)
{
    int pd = atoi(word);

    if(pd < 0 || pd >= MAX_PIPE_DESCRIPTORS_PER_PROCESS) {
        printf("invalid pipe descriptor '%s', line %i\n", word, lc);
        exit(EXIT_FAILURE);
    }
    return pd;
}

int check_bytes(char word[], int lc)
{
    int nbytes = atoi(word);

    if(nbytes <= 0) {
        printf("invalid number of bytes '%s', line %i\n", word, lc);
        exit(EXIT_FAILURE);
    }
    return nbytes;
}

//  parse_eventfile() READS AND VALIDATES THE FILE'S CONTENTS
//  YOU NEED TO STORE ITS VALUES INTO YOUR OWN DATA-STRUCTURES AND VARIABLES
void parse_eventfile(char program[], char eventfile[])
{
#define LINELEN                 100
#define WORDLEN                 20
#define CHAR_COMMENT            '#'

//  ATTEMPT TO OPEN OUR EVENTFILE, REPORTING AN ERROR IF WE CAN'T
    FILE *fp    = fopen(eventfile, "r");

    if(fp == NULL) {
        printf("%s: unable to open '%s'\n", program, eventfile);
        exit(EXIT_FAILURE);
    }

    char    line[LINELEN], words[4][WORDLEN];
    int     lc = 0;

//  READ EACH LINE FROM THE EVENTFILE, UNTIL WE REACH THE END-OF-FILE
    while(fgets(line, sizeof line, fp) != NULL) {
        ++lc;

//  COMMENT LINES ARE SIMPLY SKIPPED
        if(line[0] == CHAR_COMMENT) {
            continue;
        }

//  ATTEMPT TO BREAK EACH LINE INTO A NUMBER OF WORDS, USING sscanf()
        int nwords = sscanf(line, "%19s %19s %19s %19s",
                                    words[0], words[1], words[2], words[3]);

//  WE WILL SIMPLY IGNORE ANY LINE WITHOUT ANY WORDS
        if(nwords <= 0) {
            continue;
        }

//  ENSURE THAT THIS LINE'S PID IS VALID
        int thisPID	= check_PID(words[0], lc);
        int next	= process[thisPID].nsyscalls;

//  OTHER VALUES ON (SOME) LINES
        int otherPID, nbytes, usecs, pipedesc;

//  IDENTIFY LINES RECORDING SYSTEM-CALLS AND THEIR OTHER VALUES
//  THIS FUNCTION ONLY CHECKS INPUT;  YOU WILL NEED TO STORE THE VALUES
        if(nwords == 3 && strcmp(words[1], "compute") == 0) {
            usecs   = check_microseconds(words[2], lc);

            process[thisPID].syscalls[next].type       = SYS_COMPUTE;
            process[thisPID].syscalls[next].usecs      = usecs;
            ++process[thisPID].nsyscalls;
        }
        else if(nwords == 3 && strcmp(words[1], "sleep") == 0) {
            usecs   = check_microseconds(words[2], lc);

            process[thisPID].syscalls[next].type       = SYS_SLEEP;
            process[thisPID].syscalls[next].usecs      = usecs;
            ++process[thisPID].nsyscalls;
        }
        else if(nwords == 2 && strcmp(words[1], "exit") == 0) {

            process[thisPID].syscalls[next].type       = SYS_EXIT;
            ++process[thisPID].nsyscalls;
        }
        else if(nwords == 3 && strcmp(words[1], "fork") == 0) {
            otherPID = check_PID(words[2], lc);

            process[thisPID].syscalls[next].type       = SYS_FORK;
            process[thisPID].syscalls[next].otherPID   = otherPID;
            ++process[thisPID].nsyscalls;
        }
        else if(nwords == 3 && strcmp(words[1], "wait") == 0) {
            otherPID = check_PID(words[2], lc);

            process[thisPID].syscalls[next].type       = SYS_WAIT;
            process[thisPID].syscalls[next].otherPID   = otherPID;
            ++process[thisPID].nsyscalls;
        }
        else if(nwords == 3 && strcmp(words[1], "pipe") == 0) {
            pipedesc = check_descriptor(words[2], lc);

            process[thisPID].syscalls[next].type       = SYS_PIPE;
            process[thisPID].syscalls[next].pipedesc   = pipedesc;
            ++process[thisPID].nsyscalls;
        }
        else if(nwords == 4 && strcmp(words[1], "writepipe") == 0) {
            pipedesc = check_descriptor(words[2], lc);
            nbytes   = check_bytes(words[3], lc);

            process[thisPID].syscalls[next].type       = SYS_WRITEPIPE;
            process[thisPID].syscalls[next].pipedesc   = pipedesc;
            process[thisPID].syscalls[next].nbytes     = nbytes;
            ++process[thisPID].nsyscalls;
        }
        else if(nwords == 4 && strcmp(words[1], "readpipe") == 0) {
            pipedesc = check_descriptor(words[2], lc);
            nbytes   = check_bytes(words[3], lc);

            process[thisPID].syscalls[next].type       = SYS_READPIPE;
            process[thisPID].syscalls[next].pipedesc   = pipedesc;
            process[thisPID].syscalls[next].nbytes     = nbytes;
            ++process[thisPID].nsyscalls;
        }
//  UNRECOGNISED LINE
        else {
            printf("%s: line %i of '%s' is unrecognised\n", program,lc,eventfile);
            exit(EXIT_FAILURE);
        }
    }
    fclose(fp);

#undef  LINELEN
#undef  WORDLEN
#undef  CHAR_COMMENT
}

//  ---------------------------------------------------------------------
//  CHECK COMMAND-LINE ARGUMENTS, CALL parse_eventfile(), run_simulation()

int main(int argc, char *argv[])
{
//  ENSURE WE HAVE THE CORRECT NUMBER OF COMMAND-LINE ARGUMENTS
    if(argc != 4) {
        printf("Usage: %s eventfile timequantum-usecs pipesize-bytes\n", argv[0]);
        exit(EXIT_FAILURE);
    }

//  ENSURE THAT THE timequantum (IN MICROSECONDS) IS POSITIVE
    int timequantum = atoi(argv[2]);

    if(timequantum <= 0) {
        printf("%s: timequantum value '%s' must be positive\n", argv[0], argv[2]);
        exit(EXIT_FAILURE);
    }

//  ENSURE THAT THE pipesize (IN BYTES) IS POSITIVE
    int pipesize    = atoi(argv[3]);

    if(pipesize <= 0) {
        printf("%s: pipesize value '%s' must be positive\n", argv[0], argv[3]);
        exit(EXIT_FAILURE);
    }

    init_processes();

    parse_eventfile(argv[0], argv[1]);          // program's name, eventfile
    run_simulation(timequantum, pipesize);

    printf("timetaken %i\n", timetaken);
    return 0;
}

//  vim: ts=8 sw=4
